function CheckAll(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "ids[]"){
                ids[i].checked = parent.checked;
            }
        }
}
function CheckAll1(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "id1s[]"){
                ids[i].checked = parent.checked;
            }
        }
}
function CheckAll2(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "id2s[]"){
                ids[i].checked = parent.checked;
            }
        }
}
function CheckAll3(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "id3s[]"){
                ids[i].checked = parent.checked;
            }
        }
}
function CheckAll4(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "id4s[]"){
                ids[i].checked = parent.checked;
            }
        }
}

function CheckAll5(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "id5s[]"){
                ids[i].checked = parent.checked;
            }
        }
}

function CheckAll6(parent){
        var ids = document.getElementsByTagName('input');
        for(var i=0; i<ids.length; i++){
            if(ids[i].name == "id6s[]"){
                ids[i].checked = parent.checked;
            }
        }
}
