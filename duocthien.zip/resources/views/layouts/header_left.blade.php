<div class="br-header-left" style="align-items:center;">
	<div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
	<div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>

	<div class="tx-18 tx-gray-700 tx-uppercase tx-bold mg-l-30">Hộ kinh doanh nhà thuốc morioka</div>

</div><!-- br-header-left -->