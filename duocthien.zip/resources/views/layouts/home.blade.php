<div class="header" style="background-color:#1663ba;">
    <div class="container">
        <div id="header" class="">
            <div class="pw">
                <div class="main">
                    <a class="logo" href="https://base.vn/home">
                        <span class="image">
                            <svg width="36" height="40" viewBox="0 0 36 40" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M0 28.7126C0 29.6337 0.501461 30.485 1.31591 30.9465L16.6782 39.6525C17.4958 40.1158 18.5042 40.1158 19.3218 39.6525L34.6841 30.9465C35.4985 30.485 36 29.6337 36 28.7126V11.2874C36 10.3663 35.4985 9.51504 34.6841 9.05348L19.3218 0.347504C18.5042 -0.115835 17.4958 -0.115835 16.6782 0.347504L1.31591 9.05348C0.50146 9.51504 0 10.3663 0 11.2874V28.7126ZM19.6577 11.6968C19.6577 11.3152 19.2493 11.0655 18.8989 11.2328L16.438 12.4076C16.2559 12.4946 16.1408 12.6759 16.1418 12.8742L16.2216 28.3442C16.2236 28.7268 16.6354 28.9745 16.9851 28.8033L19.3661 27.6382C19.5448 27.5508 19.6577 27.372 19.6577 27.1765V11.6968ZM22.137 26.1143C21.7862 26.2859 21.3735 26.0363 21.3735 25.6525L21.3735 15.9208C21.3735 15.6357 21.6097 15.4046 21.9011 15.4046H24.2778C24.5691 15.4046 24.8053 15.6357 24.8053 15.9208L24.8053 24.4895C24.8053 24.6851 24.6924 24.8638 24.5137 24.9513L22.137 26.1143ZM14.5098 14.2249C14.5098 13.8411 14.0971 13.5915 13.7463 13.7631L11.3696 14.9262C11.1909 15.0136 11.078 15.1924 11.078 15.3879L11.078 23.9566C11.078 24.2417 11.3142 24.4729 11.6055 24.4729H13.9823C14.2736 24.4729 14.5098 24.2417 14.5098 23.9566L14.5098 14.2249Z"></path>
                            </svg>
                        </span>  
                        <span class="txt">Base.vn</span>
                    </a>
                <div class="tabs clear-fix">
                    <a class="tab" href="https://base.vn/home">Trang chủ</a>         

                    <div class="tab -dd js-packages unselectable">Sản phẩm <span class="-ap icon-triangle-down"></span></div>
                    
                    <div class="tab -dd js-solutions unselectable">Giải pháp <span class="-ap icon-triangle-down"></span></div>
                    
                    <a class="tab" href="https://customers.base.vn/">Khách hàng</a>
        
                    <a class="tab" href="https://base.vn/about/company">Công ty</a>
        
                    <a class="tab" href="https://base.vn/press">Báo chí</a>
        
                    <a class="tab" href="https://resources.base.vn">Resources</a>
                    
                </div>
                <div class="user">           
                    <a href="https://account.base.vn">Đăng nhập</a>
                    <span class="button js-signup-cta __inited">Đăng ký</span>          
                </div>
            </div>
        </div>
    </div>
    </div>
</div>